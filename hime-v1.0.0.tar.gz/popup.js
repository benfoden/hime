// DOM Elements
let sourceLangSpan;
let targetLangSpan;
let swapBtn;
let openOptionsBtn;
// Load settings and update UI
async function loadSettings() {
    const result = await chrome.storage.local.get(['himeSettings']);
    const settings = result.himeSettings || {
        sourceLanguage: 'English',
        targetLanguage: 'Japanese',
    };
    sourceLangSpan.textContent = settings.sourceLanguage;
    targetLangSpan.textContent = settings.targetLanguage;
}
// Swap language direction
async function swapDirection() {
    try {
        await chrome.runtime.sendMessage({ type: 'swapDirection' });
        // Reload to show updated direction
        await loadSettings();
    }
    catch (error) {
        console.error('Failed to swap direction:', error);
    }
}
// Open options page
function openOptions() {
    chrome.runtime.openOptionsPage();
}
// Initialize
document.addEventListener('DOMContentLoaded', () => {
    sourceLangSpan = document.getElementById('sourceLang');
    targetLangSpan = document.getElementById('targetLang');
    swapBtn = document.getElementById('swapBtn');
    openOptionsBtn = document.getElementById('openOptions');
    swapBtn.addEventListener('click', swapDirection);
    openOptionsBtn.addEventListener('click', openOptions);
    loadSettings();
});
export {};
//# sourceMappingURL=popup.js.map