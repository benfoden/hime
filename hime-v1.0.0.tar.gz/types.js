// Types for hime Chrome extension
// Default settings
export const DEFAULT_SETTINGS = {
    provider: 'openai',
    apiKey: '',
    model: 'gpt-5-mini',
    storageMode: 'persistent',
    sourceLanguage: 'English',
    targetLanguage: 'Japanese',
    formality: 'auto',
    composeHotkey: 'Ctrl+Shift+T',
    yoloHotkey: 'Ctrl+Shift+Y',
    swapHotkey: 'Ctrl+Shift+S',
};
// Available models per provider
export const PROVIDER_MODELS = {
    openai: ['gpt-5-mini', 'gpt-5-nano'],
    gemini: ['gemini-2.5-flash'],
};
//# sourceMappingURL=types.js.map