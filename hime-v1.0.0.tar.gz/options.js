import { DEFAULT_SETTINGS, PROVIDER_MODELS } from './types.js';
// DOM Elements
let providerSelect;
let apiKeyInput;
let modelSelect;
let storageModeSelect;
let sourceLanguageInput;
let targetLanguageInput;
let formalitySelect;
let customPromptTextarea;
let testConnectionBtn;
let saveBtn;
let statusDiv;
// Current settings
let currentSettings = { ...DEFAULT_SETTINGS };
// Load settings from storage
async function loadSettings() {
    const result = await chrome.storage.local.get(['himeSettings']);
    currentSettings = { ...DEFAULT_SETTINGS, ...result.himeSettings };
    populateForm();
    updateModelOptions();
}
// Populate form with current settings
function populateForm() {
    providerSelect.value = currentSettings.provider;
    apiKeyInput.value = currentSettings.apiKey;
    modelSelect.value = currentSettings.model;
    storageModeSelect.value = currentSettings.storageMode;
    sourceLanguageInput.value = currentSettings.sourceLanguage;
    targetLanguageInput.value = currentSettings.targetLanguage;
    formalitySelect.value = currentSettings.formality;
    customPromptTextarea.value = currentSettings.customPrompt || '';
}
// Update model options based on selected provider
function updateModelOptions() {
    const provider = providerSelect.value;
    const models = PROVIDER_MODELS[provider] || [];
    modelSelect.innerHTML = '';
    models.forEach(model => {
        const option = document.createElement('option');
        option.value = model;
        option.textContent = model;
        modelSelect.appendChild(option);
    });
    // Restore selection if valid
    const validModels = models;
    if (validModels.includes(currentSettings.model)) {
        modelSelect.value = currentSettings.model;
    }
    else {
        currentSettings.model = models[0];
        modelSelect.value = models[0];
    }
}
// Save settings to storage
async function saveSettings() {
    const newSettings = {
        provider: providerSelect.value,
        apiKey: apiKeyInput.value,
        model: modelSelect.value,
        storageMode: storageModeSelect.value,
        sourceLanguage: sourceLanguageInput.value,
        targetLanguage: targetLanguageInput.value,
        formality: formalitySelect.value,
        customPrompt: customPromptTextarea.value || undefined,
        composeHotkey: currentSettings.composeHotkey,
        yoloHotkey: currentSettings.yoloHotkey,
        swapHotkey: currentSettings.swapHotkey,
    };
    await chrome.storage.local.set({ himeSettings: newSettings });
    currentSettings = newSettings;
    showStatus('Settings saved!', 'success');
}
// Test API connection
async function testConnection() {
    const provider = providerSelect.value;
    const apiKey = apiKeyInput.value;
    const model = modelSelect.value;
    if (!apiKey) {
        showStatus('Please enter an API key first', 'error');
        return;
    }
    showStatus('Testing connection...', 'info');
    testConnectionBtn.disabled = true;
    try {
        let response;
        if (provider === 'openai') {
            response = await fetch('https://api.openai.com/v1/models', {
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                },
            });
        }
        else if (provider === 'gemini') {
            response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
        }
        else {
            throw new Error('Unknown provider');
        }
        if (response.ok) {
            showStatus('Connection successful!', 'success');
        }
        else {
            const error = await response.json().catch(() => ({ error: { message: 'Unknown error' } }));
            showStatus(`Connection failed: ${error.error?.message || response.statusText}`, 'error');
        }
    }
    catch (error) {
        showStatus(`Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`, 'error');
    }
    finally {
        testConnectionBtn.disabled = false;
    }
}
// Show status message
function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
    statusDiv.style.display = 'block';
    if (type === 'success' || type === 'info') {
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }
}
// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Get DOM elements
    providerSelect = document.getElementById('provider');
    apiKeyInput = document.getElementById('apiKey');
    modelSelect = document.getElementById('model');
    storageModeSelect = document.getElementById('storageMode');
    sourceLanguageInput = document.getElementById('sourceLanguage');
    targetLanguageInput = document.getElementById('targetLanguage');
    formalitySelect = document.getElementById('formality');
    customPromptTextarea = document.getElementById('customPrompt');
    testConnectionBtn = document.getElementById('testConnection');
    saveBtn = document.getElementById('save');
    statusDiv = document.getElementById('status');
    // Event listeners
    providerSelect.addEventListener('change', updateModelOptions);
    testConnectionBtn.addEventListener('click', testConnection);
    saveBtn.addEventListener('click', saveSettings);
    // Load settings
    loadSettings();
});
//# sourceMappingURL=options.js.map