export class GeminiProvider {
    constructor() {
        this.name = 'gemini';
    }
    async translate(text, config, apiKey, model) {
        const systemPrompt = this.buildSystemPrompt(config);
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [
                    {
                        parts: [{ text }],
                    },
                ],
                systemInstruction: {
                    parts: [{ text: systemPrompt }],
                },
            }),
        });
        if (!response.ok) {
            const error = await response.json().catch(() => ({ error: { message: 'Unknown error' } }));
            throw new Error(error.error?.message || `Gemini API error: ${response.status}`);
        }
        const data = await response.json();
        return data.candidates[0]?.content?.parts[0]?.text?.trim() || '';
    }
    buildSystemPrompt(config) {
        const formalityInstruction = this.getFormalityInstruction(config.formality);
        return `You are a translation engine. Translate the following text to ${config.targetLanguage}.
Output ONLY the translated text — no explanations, no quotes, no markdown.
Use natural, native-sounding phrasing that a native speaker would actually use.
${formalityInstruction}
${config.customPrompt || ''}`.trim();
    }
    getFormalityInstruction(formality) {
        switch (formality) {
            case 'casual':
                return 'Use casual, informal language (e.g. for Japanese: タメ口、plain form).';
            case 'polite':
                return 'Use polite, standard language (e.g. for Japanese: です/ます form).';
            case 'formal':
                return 'Use formal, respectful language (e.g. for Japanese: 敬語/keigo).';
            case 'auto':
            default:
                return 'Match the formality level to the tone of the input. Casual, informal input → casual output. Professional, formal input → polite/formal output.';
        }
    }
}
//# sourceMappingURL=gemini.js.map