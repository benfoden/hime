import type { TranslationConfig, TranslationProvider } from '../types.js';
export declare class OpenAIProvider implements TranslationProvider {
    name: string;
    translate(text: string, config: TranslationConfig, apiKey: string, model: string): Promise<string>;
    private buildSystemPrompt;
    private getFormalityInstruction;
}
//# sourceMappingURL=openai.d.ts.map