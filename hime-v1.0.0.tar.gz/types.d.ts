export interface TranslationConfig {
    sourceLanguage: string;
    targetLanguage: string;
    formality: 'auto' | 'casual' | 'polite' | 'formal';
    customPrompt?: string;
}
export interface ProviderConfig {
    provider: 'openai' | 'gemini';
    apiKey: string;
    model: string;
    storageMode: 'persistent' | 'session';
}
export interface Settings extends TranslationConfig, ProviderConfig {
    composeHotkey: string;
    yoloHotkey: string;
    swapHotkey: string;
}
export interface TranslationRequest {
    text: string;
    config: TranslationConfig;
}
export interface TranslationResponse {
    translatedText: string;
    error?: string;
}
export interface TranslationProvider {
    name: string;
    translate(text: string, config: TranslationConfig, apiKey: string, model: string): Promise<string>;
}
export type MessageType = 'translate' | 'translateResponse' | 'setBadge' | 'getSettings' | 'settingsResponse' | 'swapDirection' | 'toggleCompose' | 'yoloTranslate' | 'directionSwapped';
export interface Message {
    type: MessageType;
    payload?: unknown;
}
export interface TranslateMessage extends Message {
    type: 'translate';
    payload: {
        text: string;
        targetElement?: string;
    };
}
export interface SetBadgeMessage extends Message {
    type: 'setBadge';
    payload: {
        text: string;
        color?: string;
    };
}
export declare const DEFAULT_SETTINGS: Settings;
export declare const PROVIDER_MODELS: {
    readonly openai: readonly ["gpt-5-mini", "gpt-5-nano"];
    readonly gemini: readonly ["gemini-2.5-flash"];
};
//# sourceMappingURL=types.d.ts.map